// YOUR NAME: 
//
// CS 4318, spring 2018
// Agent Challenge 6: Hunt the wumpus
//
// Rename this file and the function below.  For example, if your agent name
// is Jones, rename this htwAgentSmith.cpp file to htwAgentJones.cpp and the
// htwAgentSmith function below to htwAgentJones.  Complete your agent
// function and turn it in on Blackboard.  Random-number generation is not
// allowed; your agent must be entirely deterministic.  Feel free to create
// other agents--each in a separate .cpp file--for comparison purposes, but
// turn in only one.  Test your agent(s) with
//
//    nice bash htwBuild.bash
//
// and then
//
//    nice ./htwRunSim
//
// Each submitted agent will explore each of many random 4x4 wumpus worlds
// to determine the standings, which will be posted soon after the agents
// are due.

#include "htw.h"

// Rename and complete this agent function.
action htwAgentSmith(WumpusWorldSensor currentSensor, bool shouldReset)
{
   // Your function must end up returning a valid action.
   // No random-number generation allowed!

   // Declare all static variables here.
   // No dynamic memory allocation allowed, but arrays are okay.

   if (shouldReset)
   {
      // Reset all static variables for each new wumpus world here.
      return doNothing;
   }
   // Perform reasoning and return action here.
   return climbOut; // Replace this return statement.
}

/*

 - First, carefully comment your code above.
 - Here, describe your approach and why you expect it to do well against the
   other submitted agents.
 - Also make a note here if you talked about the assignment with anyone or gave
   or received any kind of help.

*/
